module.exports = {
  testMatch: [
    '<rootDir>/specs/**/*.spec.{js,ts}'
  ],
};